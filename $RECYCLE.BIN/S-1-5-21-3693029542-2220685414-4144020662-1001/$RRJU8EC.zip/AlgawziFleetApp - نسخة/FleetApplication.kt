package com.aljozi.fleet

import android.app.Application
import androidx.work.Constraints
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.aljozi.fleet.data.remote.SyncWorker
import java.util.concurrent.TimeUnit

class FleetApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        setupBackgroundSync()
    }

    /**
     * جدولة مهمة المزامنة الدورية في الخلفية عند توفر شبكة الإنترنت
     */
    private fun setupBackgroundSync() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val syncRequest = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "FleetDataSyncWork",
            androidx.work.ExistingPeriodicWorkPolicy.KEEP,
            syncRequest
        )
    }
}