package com.aljozi.fleet.utils

import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Scalar
import org.opencv.imgproc.Imgproc
import kotlin.math.atan2

class FuelGaugeAnalyzer {

    /**
     * تحليل صورة عداد الوقود وحساب نسبة امتلائه بناءً على زاوية إبرة العداد.
     * @param bitmap الصورة الملتقطة بواسطة الكاميرا
     * @return نسبة مئوية تقديرية لمستوى الوقود (0% - 100%)
     */
    fun analyzeFuelLevel(bitmap: Bitmap): Float {
        val mat = Mat()
        Utils.bitmapToMat(bitmap, mat)

        // تحويل الصورة إلى رمادي لم معالجتها بصرياً
        val grayMat = Mat()
        Imgproc.cvtColor(mat, grayMat, Imgproc.COLOR_RGB2GRAY)

        // تطبيق الفلتر لتقليل الضوضاء واستخراج الحواف
        val edges = Mat()
        Imgproc.Canny(grayMat, edges, 50.0, 150.0)

        // استخراج الخطوط الممثلة لإبرة العداد باستخدام كشف Hough Lines
        val lines = Mat()
        Imgproc.HoughLinesP(edges, lines, 1.0, Math.PI / 180, 50, 30.0, 10.0)

        var estimatedPercentage = -1f

        if (lines.rows() > 0) {
            val vec = lines.get(0, 0)
            val x1 = vec[0]
            val y1 = vec[1]
            val x2 = vec[2]
            val y2 = vec[3]

            // حساب زاوية إبرة العداد بالدرجات
            val angle = Math.toDegrees(atan2(y2 - y1, x2 - x1)).toFloat()

            // تحويل الزاوية إلى نسبة مئوية مقربة
            estimatedPercentage = ((angle + 90f) / 180f * 100f).coerceIn(0f, 100f)
        }

        mat.release()
        grayMat.release()
        edges.release()
        lines.release()

        return if (estimatedPercentage >= 0f) estimatedPercentage else 50.0f
    }
}