# -*- coding: utf-8 -*-
"""
منظومة فاخر السيادية الكبرى 2600 - لوحة التشغيل الفوري المستقلة لسطح المكتب (الإصدار الذهبي المعزول)
المشرف الفني العام الأعلى: المهندس جمال سويد (أبا عبد الله)
الوظيفة: إصلاح شامل لمستشار الوقود، فك تداخل الملفات، وتأمين بيئة تشغيل الخزنة 100%
"""
import tkinter as tk
from tkinter import messagebox
import subprocess
import os
import sys

# تحديد المسار الصارم الموحد للمنظومة في قرص C لضمان الترابط التام
WORKING_DIR = "C:/Fakher_System"

class FakherDesktopMasterDashboard:
    def __init__(self, root):
        self.root = root
        self.root.title("🏛️ غـرفـة الـقـيـادة الـعـلـيـا - لـوحـة الـتـحـكم الـسيادي لأسـطـول فـاخـر 2600 🏛️")
        self.root.geometry("1400x850")
        self.root.configure(bg="#020617") 
        self.root.state('zoomed')

        # التحقق من وجود المجلد الموحد وتأمينه فوراً
        if not os.path.exists(WORKING_DIR):
            try: os.makedirs(WORKING_DIR, exist_ok=True)
            except: pass

        self.build_ui_panels()

    def build_ui_panels(self):
        # هيدر الواجهة الملكي الفاخر
        header = tk.Frame(self.root, bg="#1e1b4b", height=90, bd=2, relief="groove")
        header.pack(fill="x", padx=15, pady=15)
        
        lbl_title = tk.Label(
            header, 
            text="⚙️ لوحة مفاتيح التشغيل الفوري المستقلة لسطح المكتب - إدارة أسطول فاخر 2600 ⚙️\nالمشرف العام: المهندس جمال سويد (أبا عبد الله)", 
            font=("Arial", 16, "bold"), bg="#1e1b4b", fg="#38bdf8"
        )
        lbl_title.pack(pady=12)

        main_container = tk.Frame(self.root, bg="#020617")
        main_container.pack(fill="both", expand=True, padx=20, pady=5)

        # ----------------------------------------------------------------------
        # القطاع الأول: إدارة الهويات والتعريفات والربط
        # ----------------------------------------------------------------------
        frame_identities = tk.LabelFrame(main_container, text=" 🛡️ مفاتيح إدارة الهويات والوثائق السيادية ", font=("Arial", 12, "bold"), bg="#0f172a", fg="#f8fafc", labelanchor="ne")
        frame_identities.pack(fill="x", pady=8, ipady=10)

        # 1. زر هويات الشاحنات
        tk.Button(
            frame_identities, text="🚚 تشغيل نظام هوية وتعديل الشاحنات الشامل", font=("Arial", 11, "bold"),
            bg="#10b981", fg="white", bd=0, height=2, cursor="hand2", relief="flat",
            command=lambda: self.execute_isolated_script("Fakher_Truck_Identity_2600.py")
        ).pack(side="right", padx=15, expand=True, fill="x")

        # 2. زر وحدة السيارات الإدارية والتعريفية (تم إصلاح مسارها)
        tk.Button(
            frame_identities, text="💎 وحدة السيارات الإدارية والصيانة الذكية", font=("Arial", 11, "bold"),
            bg="#0ea5e9", fg="white", bd=0, height=2, cursor="hand2", relief="flat",
            command=lambda: self.execute_isolated_script("Fakher_Car_Identity_2600.py")
        ).pack(side="right", padx=15, expand=True, fill="x")

        # 3. زر مركز التراخيص والتشفير
        tk.Button(
            frame_identities, text="🔑 مركز التراخيص وتوليد أكواد التحقق (التشفير)", font=("Arial", 11, "bold"),
            bg="#6366f1", fg="white", bd=0, height=2, cursor="hand2", relief="flat",
            command=lambda: self.execute_isolated_script("code_generator.py")
        ).pack(side="right", padx=15, expand=True, fill="x")


        # ----------------------------------------------------------------------
        # القطاع الثاني: الرقابة والذكاء الاصطناعي (مستشار الوقود)
        # ----------------------------------------------------------------------
        frame_fuel = tk.LabelFrame(main_container, text=" ⛽ مستشار الذكاء الاصطناعي ومراقبة الهدر الفوري للوقود ", font=("Arial", 12, "bold"), bg="#0f172a", fg="#f8fafc", labelanchor="ne")
        frame_fuel.pack(fill="x", pady=8, ipady=10)

        # 4. زر عقل الذكاء الاصطناعي للشاحنات
        tk.Button(
            frame_fuel, text="📊 عقل الذكاء الاصطناعي وتقارير وقود الشاحنات", font=("Arial", 11, "bold"),
            bg="#f59e0b", fg="white", bd=0, height=2, cursor="hand2", relief="flat",
            command=lambda: self.execute_isolated_script("Fakher_Financial_And_Depreciation_Engine.py")
        ).pack(side="right", padx=15, expand=True, fill="x")

        # 5. زر مستشار وقود السيارات (تمت معالجة تفعيله هنا بشكل معزول ومباشر)
        tk.Button(
            frame_fuel, text="🚨 مستشار الرقابة ومكافحة هدر وقود السيارات", font=("Arial", 11, "bold"),
            bg="#ef4444", fg="white", bd=0, height=2, cursor="hand2", relief="flat",
            command=lambda: self.execute_isolated_script("Fakher_Car_Fuel_Consumption_2600.py")
        ).pack(side="right", padx=15, expand=True, fill="x")

        # 6. زر الواجهة المركزية الموحدة (الخزنة)
        tk.Button(
            frame_fuel, text="🏛️ استدعاء الواجهة المركزية الموحدة والشاملة (الخزنة)", font=("Arial", 11, "bold"),
            bg="#0d9488", fg="white", bd=0, height=2, cursor="hand2", relief="flat",
            command=lambda: self.execute_isolated_script("Fakher_Interface_2600.py")
        ).pack(side="right", padx=15, expand=True, fill="x")


        # ----------------------------------------------------------------------
        # القطاع الثالث: الصيانة والطباعة والتحليل
        # ----------------------------------------------------------------------
        frame_maint = tk.LabelFrame(main_container, text=" 🔧 ورش الصيانة والإنذارات المبكرة ومحرك الرقابة الجنائية والطباعة ", font=("Arial", 12, "bold"), bg="#0f172a", fg="#f8fafc", labelanchor="ne")
        frame_maint.pack(fill="x", pady=8, ipady=10)

        # 7. زر سجل صيانة الشاحنات
        tk.Button(
            frame_maint, text="🛠️ قيد سجل الصيانة الفني للشاحنات", font=("Arial", 11, "bold"),
            bg="#84cc16", fg="white", bd=0, height=2, cursor="hand2", relief="flat",
            command=lambda: self.execute_isolated_script("Truck_Maintenance_2600.py")
        ).pack(side="right", padx=10, expand=True, fill="x")

        # 8. زر سجل صيانة السيارات
        tk.Button(
            frame_maint, text="🚗 قيد سجل الصيانة لسيارات الصالون", font=("Arial", 11, "bold"),
            bg="#a855f7", fg="white", bd=0, height=2, cursor="hand2", relief="flat",
            command=lambda: self.execute_isolated_script("Car_Maintenance_2600.py")
        ).pack(side="right", padx=10, expand=True, fill="x")

        # 9. زر محرك الطباعة وسندات الصرف
        tk.Button(
            frame_maint, text="🖨️ محرك الطباعة المركزي وسندات الصرف والباركود", font=("Arial", 11, "bold"),
            bg="#14b8a6", fg="white", bd=0, height=2, cursor="hand2", relief="flat",
            command=lambda: self.execute_isolated_script("Fakher_Print_Report_Engine_2600.py")
        ).pack(side="right", padx=10, expand=True, fill="x")


        # شريط الحالة السفلي
        status_frame = tk.Frame(self.root, bg="#0f172a", height=35)
        status_frame.pack(side="bottom", fill="x")
        lbl_status = tk.Label(status_frame, text="🟢 نظام التشغيل المستقل النشط | تم حل مشكلة مستشار وقود السيارات وتأمين استدعاء المركبات بنجاح سيادي", font=("Arial", 10, "bold"), bg="#0f172a", fg="#10b981")
        lbl_status.pack(side="right", padx=20, pady=5)

    def execute_isolated_script(self, script_name):
        # مصفوفة المسارات الذكية لضمان العثور على الملف أينما كان
        possible_paths = [
            os.path.join(WORKING_DIR, script_name),
            os.path.join(os.path.dirname(__file__), script_name) if __file__ and os.path.exists(os.path.dirname(__file__)) else script_name,
            script_name
        ]
        
        target_path = None
        for p in possible_paths:
            if os.path.exists(p):
                target_path = p
                break

        if not target_path:
            messagebox.showerror("تنفيذ السيادة", f"❌ لم نتمكن من العثور على الملف البرمجي الحقيقي لـ [{script_name}].\nيرجى التأكد من نقله إلى المجلد الموحد C:/Fakher_System أولاً.")
            return

        try:
            # تشغيل البرنامج بشكل خارجي مستقل تماماً لعدم تجميد الواجهة وتفادي تداخل المتغيرات
            subprocess.Popen([sys.executable, target_path], cwd=os.path.dirname(target_path))
        except Exception as e:
            messagebox.showerror("خطأ تشغيل مستقل", f"فشل تشغيل البرنامج الخارجي:\nالتفاصيل: {e}")

if __name__ == "__main__":
    root = tk.Tk()
    app = FakherDesktopMasterDashboard(root)
    root.mainloop()