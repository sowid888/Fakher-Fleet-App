# -*- coding: utf-8 -*-
"""
منظومة فاخر السيادية الكبرى 2600 - أداة النفق الخارجي العالمي المفتوح (المطورة)
المشرف العام: المهندس جمال سويد
"""
import os
import urllib.request
import sys
import subprocess

# 1. إعدادات النفق والمنظومة
kite_file = "pagekite.py"
PORT = "5000"
DOMAIN = "fakher2600.pagekite.me"

print("==================================================")
print("   مرحباً بك في منظومة فاخر السيادية الكبرى 2600   ")
print("==================================================")

# 2. التحقق من وجود أداة النفق وتحميلها عند الحاجة
if not os.path.exists(kite_file):
    print("🔄 جاري تهيئة النفق العالمي الفاخر للمهندس جمال... يرجى الانتظار...")
    url = "https://pagekite.net/pk/pagekite.py"
    try:
        # تحديد رأس الطلب لضمان عدم الحظر أثناء التحميل
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req) as response, open(kite_file, 'wb') as out_file:
            out_file.write(response.read())
        print("✅ تم تحميل أداة النفق بنجاح!")
    except Exception as e:
        print(f"❌ تعذر تحميل الأداة بسبب قيود الشبكة أو الحظر: {e}")
        sys.exit()

# 3. دالة فحص الأمان الذكية (هنا نربط كود الذكاء الذاتي الخاص بك لاحقاً)
def smart_security_check(incoming_data):
    """
    هذه الدالة ستكون مسؤولة عن فحص البيانات القادمة من السائقين عبر النفق
    وكشف محاولات الاختراق أو البيانات المغلوطة.
    """
    print("🔍 خوارزمية الذكاء الذاتي: جاري فحص البيانات القادمة وتأمين النفق...")
    # سنضع هنا شروط الفحص وكشف الاختراق بناءً على أكوادك الأخرى
    return True

# 4. تشغيل النفق العالمي بأسلوب آمن لا يجمّد المنظومة
print(f"🚀 انطلق النفق بنجاح! جاري الاتصال بالخادم العالمي لفتح المنفذ {PORT}...")
try:
    # استخدام sys.executable يضمن تشغيل البايثون بشكل صحيح على أي جهاز ويندوز
    process = subprocess.Popen([sys.executable, kite_file, PORT, DOMAIN], 
                               stdout=subprocess.PIPE, 
                               stderr=subprocess.PIPE, 
                               text=True)
    print(f"✅ النفق يعمل الآن في الخلفية على الرابط: http://{DOMAIN}")
except Exception as e:
    print(f"❌ فشل تشغيل النفق: {e}")